export interface NewsItem {
  title: string;
  description: string;
  link: string;
  pubDate: string;
  enclosure?: {
    link: string;
  };
  thumbnail?: string;
  source: string;
}

export interface RssSource {
  url: string;
  source: string;
}

export interface PrayerTime {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

export interface PrayerTimeData {
  date: string;
  timings: PrayerTime;
}

export interface City {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
}
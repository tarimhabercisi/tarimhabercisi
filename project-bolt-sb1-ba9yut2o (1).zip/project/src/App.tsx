import React, { useState, useEffect } from 'react';
import { Clock, Moon, Sun } from 'lucide-react';
import NewsContainer from './components/NewsContainer';
import AdminPanel from './components/AdminPanel';
import PrayerTimes from './components/PrayerTimes';
import VideoNews from './components/VideoNews';
import { NewsItem, RssSource } from './types';

function App() {
  const [currentCategory, setCurrentCategory] = useState<string>('son-dakika');
  const [dateTime, setDateTime] = useState<string>('');
  const [refreshInterval, setRefreshInterval] = useState<number>(300000); // 5 minutes default
  const [showAdminPanel, setShowAdminPanel] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [rssSources, setRssSources] = useState<Record<string, RssSource[]>>({
    'son-dakika': [
      { url: 'https://rss.haberler.com/rss.asp?kategori=son-dakika', source: 'Haberler.com' },
      { url: 'https://www.cnnturk.com/feed/rss/news', source: 'CNN Türk' },
      { url: 'https://www.ntv.com.tr/son-dakika.rss', source: 'NTV' },
      { url: 'https://www.aa.com.tr/tr/rss/default?cat=guncel', source: 'Anadolu Ajansı' }
    ],
    'politika': [
      { url: 'https://rss.haberler.com/rss.asp?kategori=politika', source: 'Haberler.com' },
      { url: 'https://www.cnnturk.com/feed/rss/politika/news', source: 'CNN Türk' },
      { url: 'https://www.ntv.com.tr/politika.rss', source: 'NTV' }
    ],
    'dünya': [
      { url: 'https://rss.haberler.com/rss.asp?kategori=dunya', source: 'Haberler.com' },
      { url: 'https://www.cnnturk.com/feed/rss/dunya/news', source: 'CNN Türk' },
      { url: 'https://www.ntv.com.tr/dunya.rss', source: 'NTV' }
    ],
    'sağlık': [
      { url: 'https://rss.haberler.com/rss.asp?kategori=saglik', source: 'Haberler.com' },
      { url: 'https://www.cnnturk.com/feed/rss/saglik/news', source: 'CNN Türk' },
      { url: 'https://www.ntv.com.tr/saglik.rss', source: 'NTV' }
    ],
    'teknoloji': [
      { url: 'https://rss.haberler.com/rss.asp?kategori=teknoloji', source: 'Haberler.com' },
      { url: 'https://www.cnnturk.com/feed/rss/teknoloji/news', source: 'CNN Türk' },
      { url: 'https://www.ntv.com.tr/teknoloji.rss', source: 'NTV' }
    ],
    'sanat': [
      { url: 'https://rss.haberler.com/rss.asp?kategori=sanat', source: 'Haberler.com' },
      { url: 'https://www.cnnturk.com/feed/rss/kultur-sanat/news', source: 'CNN Türk' },
      { url: 'https://www.ntv.com.tr/sanat.rss', source: 'NTV' }
    ]
  });

  // Load dark mode preference from localStorage
  useEffect(() => {
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode !== null) {
      setDarkMode(savedDarkMode === 'true');
    } else {
      // Check if user prefers dark mode at system level
      const prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setDarkMode(prefersDarkMode);
    }
  }, []);

  // Apply dark mode class to html element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', darkMode.toString());
  }, [darkMode]);

  // Update date and time
  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
      };
      const formattedDateTime = now.toLocaleDateString('tr-TR', options);
      setDateTime(formattedDateTime);
    };

    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Handle refresh interval change
  useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(() => {
        // This would trigger a refresh of news
        console.log('Refreshing news...');
        // We would call fetchNews() here if implemented
      }, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [refreshInterval]);

  const handleRefreshIntervalChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setRefreshInterval(Number(e.target.value));
  };

  const handleCategoryClick = (category: string) => {
    setCurrentCategory(category);
  };

  const adminLogin = () => {
    const password = (document.getElementById('admin-password') as HTMLInputElement).value;
    if (password === 'admin123') {
      setShowAdminPanel(!showAdminPanel);
      (document.getElementById('admin-password') as HTMLInputElement).value = '';
    } else {
      alert('Yanlış şifre!');
    }
  };

  const addRssSource = (url: string, category: string, source: string) => {
    if (url && category && source) {
      setRssSources(prev => {
        const updatedSources = { ...prev };
        if (!updatedSources[category]) {
          updatedSources[category] = [];
        }
        updatedSources[category] = [...updatedSources[category], { url, source }];
        return updatedSources;
      });
      alert('RSS kaynağı başarıyla eklendi!');
    } else {
      alert('Lütfen tüm alanları doldurun!');
    }
  };

  const removeRssSource = (url: string, category: string) => {
    if (url && category) {
      setRssSources(prev => {
        const updatedSources = { ...prev };
        if (updatedSources[category]) {
          updatedSources[category] = updatedSources[category].filter(source => source.url !== url);
        }
        return updatedSources;
      });
      alert('RSS kaynağı başarıyla kaldırıldı!');
    } else {
      alert('Lütfen URL ve kategori seçin!');
    }
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark:bg-gray-900' : 'bg-gray-100'} flex flex-col transition-colors duration-200`}>
      <header className={`${darkMode ? 'dark:bg-gray-800 dark:text-white' : 'bg-white'} p-4 shadow-sm relative transition-colors duration-200`}>
        {/* Date and Time */}
        <div className={`absolute top-2 left-2 text-sm ${darkMode ? 'dark:text-gray-300' : 'text-gray-600'} flex items-center transition-colors duration-200`}>
          <Clock size={16} className="mr-1" />
          <span>{dateTime}</span>
        </div>
        
        {/* Prayer Times */}
        <PrayerTimes darkMode={darkMode} />
        
        {/* Dark Mode Toggle */}
        <div className="absolute top-2 right-2">
          <button 
            onClick={toggleDarkMode}
            className={`p-2 rounded-full ${darkMode ? 'bg-gray-700 text-yellow-300' : 'bg-gray-200 text-gray-700'} transition-colors duration-200`}
            aria-label={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </div>
        
        {/* Refresh Interval Control */}
        <div className={`absolute top-8 left-2 text-xs ${darkMode ? 'dark:text-gray-400' : 'text-gray-500'} transition-colors duration-200`}>
          <label htmlFor="refresh-interval" className="mr-1">Yenileme:</label>
          <select 
            id="refresh-interval" 
            value={refreshInterval} 
            onChange={handleRefreshIntervalChange}
            className={`p-1 text-xs rounded border ${darkMode ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300' : 'bg-gray-50 border-gray-300'} transition-colors duration-200`}
          >
            <option value="300000">5 Dakika</option>
            <option value="600000">10 Dakika</option>
            <option value="1800000">30 Dakika</option>
            <option value="0">Manuel</option>
          </select>
        </div>
        
        {/* Navigation Menu */}
        <nav className="mt-4">
          <ul className="flex flex-wrap justify-center space-x-4">
            {Object.keys(rssSources).map(category => (
              <li key={category}>
                <button 
                  onClick={() => handleCategoryClick(category)}
                  className={`font-bold text-sm ${
                    currentCategory === category 
                      ? 'text-blue-600 underline' 
                      : darkMode ? 'dark:text-gray-300' : 'text-gray-800'
                  } transition-colors duration-200`}
                >
                  {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </header>

      {/* Video News Section */}
      <div className="container mx-auto px-4 mt-4">
        <VideoNews darkMode={darkMode} />
      </div>

      <div className="container mx-auto p-4 flex flex-col md:flex-row gap-4 flex-grow">
        {/* Left Column */}
        <div className="w-full md:w-1/3">
          <NewsContainer 
            category={currentCategory !== 'son-dakika' ? currentCategory : 'politika'} 
            sources={rssSources[currentCategory !== 'son-dakika' ? currentCategory : 'politika'] || []} 
            darkMode={darkMode}
          />
        </div>
        
        {/* Middle Column (Son Dakika) */}
        <div className="w-full md:w-1/3">
          <NewsContainer 
            category="son-dakika" 
            sources={rssSources['son-dakika'] || []} 
            darkMode={darkMode}
          />
        </div>
        
        {/* Right Column */}
        <div className="w-full md:w-1/3">
          <NewsContainer 
            category={currentCategory !== 'son-dakika' ? 'dünya' : 'teknoloji'} 
            sources={rssSources[currentCategory !== 'son-dakika' ? 'dünya' : 'teknoloji'] || []} 
            darkMode={darkMode}
          />
        </div>
      </div>

      {/* Admin Login */}
      <div className="text-center my-8">
        <input 
          type="password" 
          id="admin-password" 
          placeholder="Yönetici Şifresi" 
          className={`p-2 rounded border ${darkMode ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400' : 'border-gray-300'} mr-2 transition-colors duration-200`}
        />
        <button 
          onClick={adminLogin}
          className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded transition-colors duration-200"
        >
          {showAdminPanel ? 'Paneli Kapat' : 'Giriş Yap'}
        </button>
      </div>

      {/* Admin Panel */}
      {showAdminPanel && (
        <AdminPanel 
          categories={Object.keys(rssSources)}
          onAddRss={addRssSource}
          onRemoveRss={removeRssSource}
          darkMode={darkMode}
        />
      )}
    </div>
  );
}

export default App;
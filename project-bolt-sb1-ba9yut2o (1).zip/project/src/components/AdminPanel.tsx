import React, { useState } from 'react';

interface AdminPanelProps {
  categories: string[];
  onAddRss: (url: string, category: string, source: string) => void;
  onRemoveRss: (url: string, category: string) => void;
  darkMode: boolean;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ categories, onAddRss, onRemoveRss, darkMode }) => {
  const [rssUrl, setRssUrl] = useState<string>('');
  const [rssCategory, setRssCategory] = useState<string>(categories[0] || '');
  const [rssSource, setRssSource] = useState<string>('');
  const [removeUrl, setRemoveUrl] = useState<string>('');
  const [removeCategory, setRemoveCategory] = useState<string>(categories[0] || '');

  const handleAddRss = () => {
    onAddRss(rssUrl, rssCategory, rssSource);
    setRssUrl('');
    setRssSource('');
  };

  const handleRemoveRss = () => {
    onRemoveRss(removeUrl, removeCategory);
    setRemoveUrl('');
  };

  return (
    <div className={`max-w-2xl mx-auto ${darkMode ? 'dark:bg-gray-800 dark:text-white' : 'bg-white'} p-6 rounded-lg shadow-md mb-8 transition-colors duration-200`}>
      <h2 className="text-2xl font-bold text-center mb-6">Yönetim Paneli</h2>
      
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">RSS Kaynağı Ekle</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="rss-url" className={`block text-sm font-medium ${darkMode ? 'dark:text-gray-300' : 'text-gray-700'} mb-1 transition-colors duration-200`}>
              RSS URL:
            </label>
            <input
              type="text"
              id="rss-url"
              value={rssUrl}
              onChange={(e) => setRssUrl(e.target.value)}
              placeholder="https://example.com/rss"
              className={`w-full p-2 border rounded ${
                darkMode 
                  ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400' 
                  : 'border-gray-300'
              } transition-colors duration-200`}
            />
          </div>
          
          <div>
            <label htmlFor="rss-source" className={`block text-sm font-medium ${darkMode ? 'dark:text-gray-300' : 'text-gray-700'} mb-1 transition-colors duration-200`}>
              Kaynak Adı:
            </label>
            <input
              type="text"
              id="rss-source"
              value={rssSource}
              onChange={(e) => setRssSource(e.target.value)}
              placeholder="Örn: CNN Türk"
              className={`w-full p-2 border rounded ${
                darkMode 
                  ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400' 
                  : 'border-gray-300'
              } transition-colors duration-200`}
            />
          </div>
          
          <div>
            <label htmlFor="rss-category" className={`block text-sm font-medium ${darkMode ? 'dark:text-gray-300' : 'text-gray-700'} mb-1 transition-colors duration-200`}>
              Kategori:
            </label>
            <select
              id="rss-category"
              value={rssCategory}
              onChange={(e) => setRssCategory(e.target.value)}
              className={`w-full p-2 border rounded ${
                darkMode 
                  ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-white' 
                  : 'border-gray-300'
              } transition-colors duration-200`}
            >
              {categories.map(category => (
                <option key={`add-${category}`} value={category}>
                  {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
                </option>
              ))}
            </select>
          </div>
          
          <button
            onClick={handleAddRss}
            className="w-full bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded transition-colors duration-200"
          >
            RSS Kaynağı Ekle
          </button>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-4">RSS Kaynağı Kaldır</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="remove-url" className={`block text-sm font-medium ${darkMode ? 'dark:text-gray-300' : 'text-gray-700'} mb-1 transition-colors duration-200`}>
              RSS URL:
            </label>
            <input
              type="text"
              id="remove-url"
              value={removeUrl}
              onChange={(e) => setRemoveUrl(e.target.value)}
              placeholder="https://example.com/rss"
              className={`w-full p-2 border rounded ${
                darkMode 
                  ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400' 
                  : 'border-gray-300'
              } transition-colors duration-200`}
            />
          </div>
          
          <div>
            <label htmlFor="remove-category" className={`block text-sm font-medium ${darkMode ? 'dark:text-gray-300' : 'text-gray-700'} mb-1 transition-colors duration-200`}>
              Kategori:
            </label>
            <select
              id="remove-category"
              value={removeCategory}
              onChange={(e) => setRemoveCategory(e.target.value)}
              className={`w-full p-2 border rounded ${
                darkMode 
                  ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-white' 
                  : 'border-gray-300'
              } transition-colors duration-200`}
            >
              {categories.map(category => (
                <option key={`remove-${category}`} value={category}>
                  {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
                </option>
              ))}
            </select>
          </div>
          
          <button
            onClick={handleRemoveRss}
            className="w-full bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded transition-colors duration-200"
          >
            RSS Kaynağı Kaldır
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
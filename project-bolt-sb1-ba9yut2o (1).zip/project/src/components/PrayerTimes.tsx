import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Clock } from 'lucide-react';
import { PrayerTimeData, City } from '../types';

interface PrayerTimesProps {
  darkMode: boolean;
}

// Turkish cities with coordinates
const turkishCities: City[] = [
  { id: 1, name: 'İstanbul', latitude: 41.0082, longitude: 28.9784 },
  { id: 2, name: 'Ankara', latitude: 39.9334, longitude: 32.8597 },
  { id: 3, name: 'İzmir', latitude: 38.4237, longitude: 27.1428 },
  { id: 4, name: 'Bursa', latitude: 40.1885, longitude: 29.0610 },
  { id: 5, name: 'Antalya', latitude: 36.8969, longitude: 30.7133 },
  { id: 6, name: 'Adana', latitude: 37.0000, longitude: 35.3213 },
  { id: 7, name: 'Konya', latitude: 37.8667, longitude: 32.4833 },
  { id: 8, name: 'Gaziantep', latitude: 37.0662, longitude: 37.3833 },
  { id: 9, name: 'Şanlıurfa', latitude: 37.1591, longitude: 38.7969 },
  { id: 10, name: 'Kayseri', latitude: 38.7312, longitude: 35.4787 }
];

const PrayerTimes: React.FC<PrayerTimesProps> = ({ darkMode }) => {
  const [selectedCity, setSelectedCity] = useState<City>(turkishCities[0]);
  const [prayerTimes, setPrayerTimes] = useState<PrayerTimeData | null>(null);
  const [nextPrayer, setNextPrayer] = useState<{ name: string; time: string } | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Prayer names in Turkish
  const prayerNamesInTurkish: Record<string, string> = {
    'Fajr': 'İmsak',
    'Sunrise': 'Güneş',
    'Dhuhr': 'Öğle',
    'Asr': 'İkindi',
    'Maghrib': 'Akşam',
    'Isha': 'Yatsı'
  };

  // Fetch prayer times for selected city
  useEffect(() => {
    const fetchPrayerTimes = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth() + 1;
        const day = today.getDate();
        
        const response = await axios.get(
          `https://api.aladhan.com/v1/timings/${day}-${month}-${year}`,
          {
            params: {
              latitude: selectedCity.latitude,
              longitude: selectedCity.longitude,
              method: 13 // Method 13 is for Turkey
            }
          }
        );
        
        if (response.data && response.data.data) {
          setPrayerTimes(response.data.data);
        } else {
          setError('Namaz vakitleri alınamadı.');
        }
      } catch (err) {
        console.error('Error fetching prayer times:', err);
        setError('Namaz vakitleri yüklenirken bir hata oluştu.');
      } finally {
        setLoading(false);
      }
    };

    fetchPrayerTimes();
  }, [selectedCity]);

  // Calculate next prayer time and remaining time
  useEffect(() => {
    if (!prayerTimes) return;

    const calculateNextPrayer = () => {
      const now = new Date();
      const currentTime = now.getHours() * 60 + now.getMinutes();
      
      const prayers = [
        { name: 'Fajr', time: prayerTimes.timings.Fajr },
        { name: 'Sunrise', time: prayerTimes.timings.Sunrise },
        { name: 'Dhuhr', time: prayerTimes.timings.Dhuhr },
        { name: 'Asr', time: prayerTimes.timings.Asr },
        { name: 'Maghrib', time: prayerTimes.timings.Maghrib },
        { name: 'Isha', time: prayerTimes.timings.Isha }
      ];
      
      // Convert prayer times to minutes since midnight
      const prayerMinutes = prayers.map(prayer => {
        const [hours, minutes] = prayer.time.split(':').map(Number);
        return { name: prayer.name, minutes: hours * 60 + minutes };
      });
      
      // Find the next prayer
      let next = prayerMinutes.find(prayer => prayer.minutes > currentTime);
      
      // If no next prayer today, the next prayer is Fajr tomorrow
      if (!next) {
        next = { name: 'Fajr', minutes: prayerMinutes[0].minutes + 24 * 60 };
      }
      
      // Calculate remaining time
      let remainingMinutes = next.minutes - currentTime;
      if (remainingMinutes < 0) {
        remainingMinutes += 24 * 60; // Add 24 hours if it's tomorrow
      }
      
      const hours = Math.floor(remainingMinutes / 60);
      const minutes = remainingMinutes % 60;
      
      // Format the time
      const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      
      // Find the original time string
      const originalPrayer = prayers.find(p => p.name === next.name);
      
      setNextPrayer({ 
        name: next.name, 
        time: originalPrayer ? originalPrayer.time : '' 
      });
      setTimeRemaining(`${hours}s ${minutes}dk`);
    };
    
    calculateNextPrayer();
    const interval = setInterval(calculateNextPrayer, 60000); // Update every minute
    
    return () => clearInterval(interval);
  }, [prayerTimes]);

  const handleCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const cityId = Number(e.target.value);
    const city = turkishCities.find(c => c.id === cityId);
    if (city) {
      setSelectedCity(city);
      localStorage.setItem('selectedCity', JSON.stringify(city));
    }
  };

  // Load selected city from localStorage
  useEffect(() => {
    const savedCity = localStorage.getItem('selectedCity');
    if (savedCity) {
      try {
        const city = JSON.parse(savedCity);
        setSelectedCity(city);
      } catch (err) {
        console.error('Error parsing saved city:', err);
      }
    }
  }, []);

  if (loading) {
    return (
      <div className={`absolute top-8 right-2 flex items-center ${darkMode ? 'dark:text-gray-300' : 'text-gray-600'} text-xs transition-colors duration-200`}>
        <div className="animate-pulse">
          <div className={`h-4 w-24 ${darkMode ? 'dark:bg-gray-700' : 'bg-gray-200'} rounded`}></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`absolute top-8 right-2 flex items-center ${darkMode ? 'dark:text-gray-300' : 'text-gray-600'} text-xs transition-colors duration-200`}>
        <span className="text-red-500">Namaz vakti bilgisi alınamadı</span>
      </div>
    );
  }

  return (
    <div className={`absolute top-8 right-2 flex flex-col items-end ${darkMode ? 'dark:text-gray-300' : 'text-gray-600'} text-xs transition-colors duration-200`}>
      <div className="flex items-center mb-1">
        <select
          value={selectedCity.id}
          onChange={handleCityChange}
          className={`p-1 text-xs rounded border mr-2 ${
            darkMode 
              ? 'dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300' 
              : 'bg-gray-50 border-gray-300'
          } transition-colors duration-200`}
        >
          {turkishCities.map(city => (
            <option key={city.id} value={city.id}>
              {city.name}
            </option>
          ))}
        </select>
        <Clock size={12} className="mr-1" />
      </div>
      
      {nextPrayer && (
        <div className="flex flex-col items-end">
          <span className="font-semibold">
            {prayerNamesInTurkish[nextPrayer.name]} Vaktine: {timeRemaining}
          </span>
          <span className="text-xs opacity-75">
            {prayerNamesInTurkish[nextPrayer.name]} Vakti: {nextPrayer.time.substring(0, 5)}
          </span>
        </div>
      )}
    </div>
  );
};

export default PrayerTimes;
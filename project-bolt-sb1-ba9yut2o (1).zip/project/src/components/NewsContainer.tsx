import React, { useState, useEffect } from 'react';
import { NewsItem, RssSource } from '../types';

interface NewsContainerProps {
  category: string;
  sources: RssSource[];
  darkMode: boolean;
}

const NewsContainer: React.FC<NewsContainerProps> = ({ category, sources, darkMode }) => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchNews = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const allNews: NewsItem[] = [];
        const apiKey = 'f0url4ftr6qusod3xbtlkw1kwu1vnfsjzzv7jad9'; // This is a placeholder, use your own API key
        
        for (const { url, source } of sources) {
          const proxyUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(url)}&api_key=${apiKey}`;
          
          try {
            const response = await fetch(proxyUrl);
            const data = await response.json();
            
            if (data.items) {
              // Filter news from the last 24 hours
              const now = new Date();
              const filteredNews = data.items
                .filter((item: any) => {
                  const newsDate = new Date(item.pubDate);
                  const timeDifference = now.getTime() - newsDate.getTime();
                  return timeDifference <= 24 * 60 * 60 * 1000; // 24 hours in milliseconds
                })
                .map((item: any) => ({ ...item, source }));
              
              allNews.push(...filteredNews);
            }
          } catch (err) {
            console.error(`Error fetching from ${url}:`, err);
          }
        }
        
        // Sort news by date (newest first)
        const sortedNews = allNews.sort((a, b) => 
          new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime()
        );
        
        setNews(sortedNews);
      } catch (err) {
        console.error('Error fetching news:', err);
        setError('Haberler yüklenirken bir hata oluştu. Lütfen daha sonra tekrar deneyin.');
      } finally {
        setLoading(false);
      }
    };

    if (sources.length > 0) {
      fetchNews();
    } else {
      setNews([]);
      setLoading(false);
    }
  }, [sources]);

  if (loading) {
    return (
      <div className={`${darkMode ? 'dark:bg-gray-800 dark:text-white' : 'bg-white'} p-4 rounded shadow-sm transition-colors duration-200`}>
        <h2 className="text-xl font-bold mb-4 capitalize">{category.replace('-', ' ')}</h2>
        <div className="animate-pulse flex flex-col space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="space-y-2">
              <div className={`h-40 ${darkMode ? 'dark:bg-gray-700' : 'bg-gray-200'} rounded transition-colors duration-200`}></div>
              <div className={`h-4 ${darkMode ? 'dark:bg-gray-700' : 'bg-gray-200'} rounded w-3/4 transition-colors duration-200`}></div>
              <div className={`h-4 ${darkMode ? 'dark:bg-gray-700' : 'bg-gray-200'} rounded transition-colors duration-200`}></div>
              <div className={`h-4 ${darkMode ? 'dark:bg-gray-700' : 'bg-gray-200'} rounded w-1/2 transition-colors duration-200`}></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`${darkMode ? 'dark:bg-gray-800 dark:text-white' : 'bg-white'} p-4 rounded shadow-sm transition-colors duration-200`}>
        <h2 className="text-xl font-bold mb-4 capitalize">{category.replace('-', ' ')}</h2>
        <div className="text-red-500">{error}</div>
      </div>
    );
  }

  return (
    <div className={`${darkMode ? 'dark:bg-gray-800 dark:text-white' : 'bg-white'} p-4 rounded shadow-sm transition-colors duration-200`}>
      <h2 className="text-xl font-bold mb-4 capitalize">{category.replace('-', ' ')}</h2>
      {news.length === 0 ? (
        <p className={darkMode ? 'dark:text-gray-300' : 'text-gray-700'}>Bu kategoride haber bulunamadı.</p>
      ) : (
        news.map((item, index) => (
          <div key={index} className={`mb-6 pb-6 ${darkMode ? 'border-gray-700' : 'border-gray-200'} border-b last:border-0 transition-colors duration-200`}>
            {(item.enclosure?.link || item.thumbnail) && (
              <img 
                src={item.enclosure?.link || item.thumbnail} 
                alt={item.title} 
                className="w-full h-auto rounded mb-3 object-cover"
              />
            )}
            <h3 className="text-lg font-bold mb-2">{item.title}</h3>
            <p className={`text-sm ${darkMode ? 'dark:text-gray-300' : 'text-gray-700'} mb-2 transition-colors duration-200`}>
              {item.description.replace(/<[^>]+>/g, '').substring(0, 150)}...
            </p>
            <div className={`flex justify-between items-center text-xs ${darkMode ? 'dark:text-gray-400' : 'text-gray-500'} mb-2 transition-colors duration-200`}>
              <span>{item.source}</span>
              <span>
                {new Date(item.pubDate).toLocaleDateString('tr-TR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>
            <a 
              href={item.link} 
              target="_blank" 
              rel="noopener noreferrer"
              className={`${darkMode ? 'text-green-400' : 'text-green-600'} hover:underline text-sm font-medium transition-colors duration-200`}
            >
              Devamını oku...
            </a>
          </div>
        ))
      )}
    </div>
  );
};

export default NewsContainer;
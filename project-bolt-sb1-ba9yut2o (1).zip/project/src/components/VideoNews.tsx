import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface VideoNewsProps {
  darkMode: boolean;
}

interface YouTubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  publishedAt: string;
}

const VideoNews: React.FC<VideoNewsProps> = ({ darkMode }) => {
  const [showFullscreen, setShowFullscreen] = useState<boolean>(false);
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  
  const PLAYLIST_ID = 'PL3ZQ5CpNulQnhaVd-ty0jdN-d_hBHvLTE';
  const API_KEY = 'AIzaSyB3PnyPHZqWZaQ--_V00rmCZegn60qhlTM';

  useEffect(() => {
    const fetchVideos = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const response = await axios.get(
          'https://www.googleapis.com/youtube/v3/playlistItems',
          {
            params: {
              part: 'snippet',
              maxResults: 10,
              playlistId: PLAYLIST_ID,
              key: API_KEY
            }
          }
        );
        
        if (response.data && response.data.items) {
          const fetchedVideos = response.data.items.map((item: any) => ({
            id: item.snippet.resourceId.videoId,
            title: item.snippet.title,
            thumbnail: item.snippet.thumbnails.medium.url,
            publishedAt: new Date(item.snippet.publishedAt).toLocaleDateString('tr-TR')
          }));
          
          setVideos(fetchedVideos);
          
          // Set the first video as selected by default
          if (fetchedVideos.length > 0 && !selectedVideo) {
            setSelectedVideo(fetchedVideos[0].id);
          }
        }
      } catch (err) {
        console.error('Error fetching YouTube videos:', err);
        setError('Video verileri yüklenirken bir hata oluştu.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchVideos();
  }, []);

  const toggleFullscreen = () => {
    setShowFullscreen(!showFullscreen);
  };

  const handleVideoSelect = (videoId: string) => {
    setSelectedVideo(videoId);
    
    // Scroll to the video player on mobile
    if (window.innerWidth < 768) {
      const videoPlayer = document.getElementById('video-player');
      if (videoPlayer) {
        videoPlayer.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <div className={`${darkMode ? 'dark:bg-gray-800 dark:text-white' : 'bg-white'} p-4 rounded shadow-sm mb-4 transition-colors duration-200`}>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Video Haberler</h2>
        <button 
          onClick={toggleFullscreen}
          className={`px-3 py-1 rounded text-sm ${darkMode ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'} transition-colors duration-200`}
        >
          {showFullscreen ? 'Küçült' : 'Büyüt'}
        </button>
      </div>
      
      {loading ? (
        <div className="animate-pulse">
          <div className={`${darkMode ? 'bg-gray-700' : 'bg-gray-200'} pb-[56.25%] h-0 rounded-lg mb-4`}></div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-2">
                <div className={`${darkMode ? 'bg-gray-700' : 'bg-gray-200'} pb-[56.25%] h-0 rounded`}></div>
                <div className={`h-4 ${darkMode ? 'bg-gray-700' : 'bg-gray-200'} rounded w-3/4`}></div>
              </div>
            ))}
          </div>
        </div>
      ) : error ? (
        <div className="text-red-500 text-center py-4">{error}</div>
      ) : (
        <div className="flex flex-col md:flex-row gap-4">
          {/* Main Video Player */}
          <div className={`md:w-2/3 ${showFullscreen ? 'w-full' : ''}`} id="video-player">
            <div className={`relative ${showFullscreen ? 'h-[70vh]' : 'pb-[56.25%] h-0'} overflow-hidden rounded-lg`}>
              {selectedVideo && (
                <iframe 
                  width="560" 
                  height="315" 
                  src={`https://www.youtube.com/embed/${selectedVideo}?autoplay=0&rel=0`}
                  title="YouTube video player" 
                  frameBorder="0" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                  referrerPolicy="strict-origin-when-cross-origin" 
                  allowFullScreen
                  className="absolute top-0 left-0 w-full h-full"
                ></iframe>
              )}
            </div>
            
            {/* Current Video Title */}
            {selectedVideo && (
              <h3 className="mt-2 font-semibold">
                {videos.find(v => v.id === selectedVideo)?.title || 'Video Yükleniyor...'}
              </h3>
            )}
          </div>
          
          {/* Video List */}
          {!showFullscreen && (
            <div className="md:w-1/3 mt-4 md:mt-0">
              <h3 className="text-lg font-semibold mb-2">Son Videolar</h3>
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                {videos.map((video) => (
                  <div 
                    key={video.id}
                    onClick={() => handleVideoSelect(video.id)}
                    className={`flex gap-2 cursor-pointer p-2 rounded ${
                      selectedVideo === video.id 
                        ? darkMode ? 'bg-gray-700' : 'bg-gray-100' 
                        : ''
                    } hover:${darkMode ? 'bg-gray-700' : 'bg-gray-100'} transition-colors duration-200`}
                  >
                    <div className="w-1/3 flex-shrink-0">
                      <div className="relative pb-[56.25%] h-0">
                        <img 
                          src={video.thumbnail} 
                          alt={video.title} 
                          className="absolute top-0 left-0 w-full h-full object-cover rounded"
                        />
                      </div>
                    </div>
                    <div className="w-2/3">
                      <p className="text-sm font-medium line-clamp-2">{video.title}</p>
                      <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'} mt-1`}>
                        {video.publishedAt}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      
      <div className="mt-4 text-center">
        <a 
          href={`https://youtube.com/playlist?list=${PLAYLIST_ID}`}
          target="_blank" 
          rel="noopener noreferrer"
          className={`text-sm ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-800'} transition-colors duration-200`}
        >
          Tüm videoları YouTube'da görüntüle
        </a>
      </div>
    </div>
  );
};

export default VideoNews;